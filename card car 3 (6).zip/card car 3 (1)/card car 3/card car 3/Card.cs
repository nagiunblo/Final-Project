﻿public class Card
{
    public string Name;
    public int Attack;
    public int Health;

    public Card(string name, int attack, int health)
    {
        Name = name;
        Attack = attack;
        Health = health;
    }

    public override string ToString()
    {
        return $"{Name} (ATK:{Attack} HP:{Health})";
    }
}
