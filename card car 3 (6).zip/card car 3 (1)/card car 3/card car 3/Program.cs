﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        List<Card> playerDeck = new List<Card>();
        List<Card> enemyDeck = new List<Card>();
        List<Card> allCards = new List<Card>();

        playerDeck.Add(new Card("bear", 2, 5));
        playerDeck.Add(new Card("sloth", 1, 2));
        playerDeck.Add(new Card("ferret", 1, 2));
        playerDeck.Add(new Card("rat", 1, 1));

        enemyDeck.Add(new Card("bear", 2, 5));
        enemyDeck.Add(new Card("sloth", 1, 2));
        enemyDeck.Add(new Card("ferret", 1, 2));
        enemyDeck.Add(new Card("rat", 1, 1));

        allCards.AddRange(playerDeck);

        Character player = new Character(playerDeck, "You", 10);
        Character enemy = new Character(enemyDeck, "Enemy", 10);
        Field field = new Field();

        for (int i = 0; i < 4; i++)
        {
            player.ChooseCard(false, false);
            enemy.ChooseCard(false, true);
        }

        while (true)
        {
            Console.Clear();
            field.Display();
            Console.WriteLine(player.Name + " Health: " + player.Health + " | " + enemy.Name + " Health: " + enemy.Health);

            if (player.Hand.Count == 0 && player.Deck.Count == 0)
            {
                Card emergency = allCards[0];
                player.Hand.Add(new Card(emergency.Name, emergency.Attack, emergency.Health));
                Console.WriteLine("⚠️ " + player.Name + " was out of cards! A backup " + emergency.Name + " was added.");
            }

            player.DisplayHand();

            bool hasEmptySlot = false;
            for (int i = 0; i < 4; i++)
            {
                if (field.PlayerSlots[i] == null)
                {
                    hasEmptySlot = true;
                    break;
                }
            }

            if (hasEmptySlot && player.Hand.Count > 0)
            {
                Console.WriteLine("Choose a card index to play or type 'skip':");
                string input = Console.ReadLine();

                switch (input.ToLower())
                {
                    case "skip":
                        Console.WriteLine("You skipped your turn.");
                        break;
                    default:
                        int cardIndex;
                        if (!int.TryParse(input, out cardIndex) || cardIndex < 0 || cardIndex >= player.Hand.Count)
                        {
                            Console.WriteLine("Invalid card index.");
                            Console.ReadKey();
                            continue;
                        }

                        Console.WriteLine("Choose a field slot (0–3):");
                        int slotIndex;
                        if (!int.TryParse(Console.ReadLine(), out slotIndex) || slotIndex < 0 || slotIndex >= 4)
                        {
                            Console.WriteLine("Invalid slot index.");
                            Console.ReadKey();
                            continue;
                        }

                        if (field.PlayerSlots[slotIndex] != null)
                        {
                            Console.WriteLine("Slot already occupied.");
                            Console.ReadKey();
                            continue;
                        }

                        field.PlayerSlots[slotIndex] = player.Hand[cardIndex];
                        player.Hand.RemoveAt(cardIndex);
                        break;
                }
            }

            enemy.ChooseCard(false, true);
            if (enemy.Hand.Count > 0)
            {
                Random rng = new Random();
                int enemyCardIndex = rng.Next(enemy.Hand.Count);
                List<int> emptySlots = new List<int>();
                for (int i = 0; i < 4; i++)
                {
                    if (field.EnemySlots[i] == null) emptySlots.Add(i);
                }
                if (emptySlots.Count > 0)
                {
                    int enemySlot = emptySlots[rng.Next(emptySlots.Count)];
                    field.EnemySlots[enemySlot] = enemy.Hand[enemyCardIndex];
                    enemy.Hand.RemoveAt(enemyCardIndex);
                }
            }

            Console.WriteLine();
            Console.WriteLine("Combat Phase:");

            for (int i = 0; i < 4; i++)
            {
                Card playerAttacker = field.PlayerSlots[i];
                Card enemyDefender = field.EnemySlots[i];

                if (playerAttacker != null)
                {
                    if (enemyDefender != null)
                    {
                        Console.WriteLine(player.Name + "'s " + playerAttacker.Name + " attacks " + enemy.Name + "'s " + enemyDefender.Name + "!");
                        enemyDefender.Health -= playerAttacker.Attack;
                        if (enemyDefender.Health > 0)
                        {
                            playerAttacker.Health -= enemyDefender.Attack;
                        }
                        if (enemyDefender.Health <= 0) field.EnemySlots[i] = null;
                        if (playerAttacker.Health <= 0) field.PlayerSlots[i] = null;
                    }
                    else
                    {
                        Console.WriteLine(player.Name + "'s " + playerAttacker.Name + " attacks directly!");
                        enemy.Health -= playerAttacker.Attack;
                        if (enemy.Health <= 0)
                        {
                            Console.WriteLine(player.Name + " wins!");
                            return;
                        }
                    }
                }
            }


            for (int i = 0; i < 4; i++)
            {
                Card enemyAttacker = field.EnemySlots[i];
                Card playerDefender = field.PlayerSlots[i];

                if (enemyAttacker != null)
                {
                    if (playerDefender != null)
                    {
                        Console.WriteLine(enemy.Name + "'s " + enemyAttacker.Name + " attacks " + player.Name + "'s " + playerDefender.Name + "!");
                        playerDefender.Health -= enemyAttacker.Attack;
                        if (playerDefender.Health > 0)
                        {
                            enemyAttacker.Health -= playerDefender.Attack;
                        }
                        if (playerDefender.Health <= 0) field.PlayerSlots[i] = null;
                        if (enemyAttacker.Health <= 0) field.EnemySlots[i] = null;
                    }
                    else
                    {
                        Console.WriteLine(enemy.Name + "'s " + enemyAttacker.Name + " attacks directly!");
                        player.Health -= enemyAttacker.Attack;
                        if (player.Health <= 0)
                        {
                            Console.WriteLine(enemy.Name + " wins!");
                            return;
                        }
                    }
                }
            }


            Console.WriteLine();
            Console.WriteLine("Press Enter for next turn...");
            Console.ReadLine();
        }
    }
}
