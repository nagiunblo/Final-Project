﻿using System;
using System.Collections.Generic;

public class Character
{
    public List<Card> Deck;
    public List<Card> Hand;
    public int Health;
    public string Name;

    private Random rng = new Random();

    public Character(List<Card> deck, string name, int health)
    {
        Deck = new List<Card>(deck);
        Hand = new List<Card>();
        Name = name;
        Health = health;
    }

    public void ChooseCard(bool showMessage, bool drawRandomly)
    {
        if (Deck.Count > 0)
        {
            Card drawn;
            if (drawRandomly)
            {
                int index = rng.Next(Deck.Count);
                drawn = Deck[index];
                Deck.RemoveAt(index);
            }
            else
            {
                drawn = Deck[0];
                Deck.RemoveAt(0);
            }

            Hand.Add(drawn);

            if (showMessage)
            {
                Console.WriteLine(Name + " drew " + drawn.Name + ".");
            }
        }
    }




    public void DisplayHand()
    {
        Console.WriteLine(Name + "'s Hand:");
        for (int i = 0; i < Hand.Count; i++)
        {
            Console.WriteLine(i + ": " + Hand[i]);
        }
    }

}
