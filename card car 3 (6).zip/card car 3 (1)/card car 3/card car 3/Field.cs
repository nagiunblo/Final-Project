﻿public class Field
{
    public Card[] PlayerSlots = new Card[4];
    public Card[] EnemySlots = new Card[4];

    public void Display()
    {
        Console.WriteLine("Field:");
        for (int i = 0; i < 4; i++)
        {
            string playerCard = PlayerSlots[i] != null ? PlayerSlots[i].ToString() : "[empty]";
            string enemyCard = EnemySlots[i] != null ? EnemySlots[i].ToString() : "[empty]";
            Console.WriteLine("Slot " + i + ": You → " + playerCard + " | Enemy → " + enemyCard);
        }
        Console.WriteLine();
    }
}
